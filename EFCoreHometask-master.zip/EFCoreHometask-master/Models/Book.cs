﻿using Models.Abstract;
using System.Collections.Generic;

namespace Models
{
    public class Book : Entity
    {
        public string Name { get; set; }
        public virtual ICollection<Author> Authors { get; set; }
        public virtual ICollection<Visitor> Visitors { get; set; }
    }
}
