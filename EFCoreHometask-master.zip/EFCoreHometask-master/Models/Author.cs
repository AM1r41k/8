﻿using Models.Abstract;
using System.Collections.Generic;

namespace Models
{
    public class Author : Entity
    {
        public string FullName { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }
}
