﻿using Models.Abstract;
using System.Collections.Generic;

namespace Models
{
    public class Visitor : Entity
    {
        public string Name { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }
}

