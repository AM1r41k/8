﻿using Microsoft.EntityFrameworkCore;
using Models;

namespace Data
{
    public class LibraryContext : DbContext
    {
        public LibraryContext()
        {
            Database.EnsureCreated();
        }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Visitor> Visitors { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server = DESKTOP - H5GCVAL; Database = LibraryDatabase; Trusted_Connection = true;");
        }
    }
}
