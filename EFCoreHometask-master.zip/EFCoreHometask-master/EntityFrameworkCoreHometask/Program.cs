﻿using Data;
using System;
using System.Linq;

namespace EntityFrameworkCoreHometask
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1) Выведите список должников.
            using (var context = new LibraryContext())
            {
                var debtors = context.Visitors.Select(visitors => visitors);
                foreach (var debtor in debtors)
                {
                    Console.WriteLine(debtor);
                }

                Console.WriteLine();
            // 2) Выведите список авторов книги №3(по порядку из таблицы ‘Book’).
         
            var bookThreeAuthors = context.Authors.Where(books => books.Id.Equals(3)).ToList();
            foreach (var author in bookThreeAuthors)
            {
                Console.WriteLine(author.FullName);
            }

            Console.WriteLine();
                //3) Выведите список книг, которые доступны в данный момент. 
                    var booksNotInUse = context.Books.Where(visitors => visitors.Id.Equals("null"));
                    foreach (var book in booksNotInUse)
                    {
                        Console.WriteLine(book.Name);
                    }
                    Console.WriteLine();

                //4) Вывести список книг, которые на руках у пользователя №2.
                var secondVisitorBooks = context.Books.Where(visitors => visitors.Visitors.Equals(2));                  
                    foreach (var book in secondVisitorBooks)
                    {
                        Console.WriteLine(book.Name);
                    }
                    Console.WriteLine();

                //5) Обнулите задолженности всех должников. 
                foreach (var debtor in debtors)
                {
                    debtor.Books.Clear();
                    Console.WriteLine("All debts are forgiven!");
                }
                    Console.WriteLine();
            }
        }
    }
}
